package com.example.easymart.presentation.ui.deliveryaddress

import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState

@Composable
fun DeliveryAddressRoute(
    viewModel: AddressViewModel,
    onAddressAddClick: () -> Unit,
    onAddressEditClick: (addressId: Int) -> Unit,
    onAddressDeleteClick: (addressId: Int) -> Unit
){
    val address = viewModel.addresses.collectAsState()
    DeliveryAddressScreen(
        addresses = address.value,
        onAddressAddClick = onAddressAddClick,
        onAddressEditClick = onAddressEditClick,
        onAddressDeleteClick = onAddressDeleteClick
    )
}
